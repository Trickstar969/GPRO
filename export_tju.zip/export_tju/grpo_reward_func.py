"""
UAV 航迹规划 GRPO 奖励函数
swift rlhf  --rlhf_type grpo \
            --external_plugins utils/grpo_reward_func.py \
            --reward_funcs uav_trajectory \
            ...

设计依据来自 encode_data2prompt.py 中的 prompt_role 与 prompt_contrain：
1. 三架无人机合围目标点 T；
2. 终点应均匀分布在以 T 为圆心、半径 1000m 的圆周上，互成 120°；
3. 总轨迹长度偏差 <= 500m；
4. 相邻三点转弯角 <= 60°；
5. 倒数第二点、终点、目标点形成的转弯角 <= 60°；
6. 每架无人机航迹点数量 3~10 个；
7. 总航迹越短越好。
"""

import re
import math
from typing import List, Tuple, Optional
import numpy as np

# 兼容本地测试与 MS-Swift 插件环境
try:
    from swift.plugin import ORM, orms
except ImportError:
    ORM = object
    orms = {}


# --------------------------- 解析与几何计算工具 ---------------------------

def _extract_all_numbers(text: str) -> List[float]:
    """从文本中提取所有整数/浮点数（含负号）。"""
    return [float(x) for x in re.findall(r'-?\d+\.?\d*', text)]


def _extract_bracket_contents(text: str) -> List[str]:
    """提取所有方括号 [] 内的原始字符串。"""
    return re.findall(r'\[(.*?)\]', text)


def parse_query_line(line: str) -> Tuple[np.ndarray, List[np.ndarray]]:
    """
    解析 [QUERY] 行。

    Returns:
        target: np.ndarray, shape (2,), 目标点 T
        starts: List[np.ndarray], 3 架无人机的起点 S
    """
    brackets = _extract_bracket_contents(line)
    # 兼容带 [QUERY] 前缀或不带前缀的 query 文本
    start_idx = 0
    if brackets and brackets[0].strip().upper() in ('QUERY', '[QUERY]'):
        start_idx = 1

    # 结构: ([QUERY],) [tx, ty], [uav1_sx, uav1_sy], [uav2_sx, uav2_sy], [uav3_sx, uav3_sy]
    if len(brackets) < start_idx + 4:
        raise ValueError(f"QUERY 行方括号数量不足: {line[:80]}")

    target = _extract_all_numbers(brackets[start_idx])
    if len(target) != 2:
        raise ValueError(f"目标点坐标数量错误: {target}")

    starts = []
    for i in range(3):
        s = _extract_all_numbers(brackets[start_idx + 1 + i])
        if len(s) != 2:
            raise ValueError(f"无人机 {i + 1} 起点坐标数量错误: {s}")
        starts.append(np.array(s, dtype=float))

    return np.array(target, dtype=float), starts


def parse_trajectory_line(line: str) -> Tuple[List[int], List[List[float]]]:
    """
    解析 [LABELS] 或 [RESPONSE] 行中的三架无人机航迹。

    Returns:
        segments: List[int], 每架无人机“除起点外”的航迹点数量
        nodes:    List[List[float]], 每架无人机除起点外的展平坐标序列
    """
    # 去掉行首标签
    clean = re.sub(r'^\s*\[(?:RESPONSE|LABELS)\]\s*', '', line)

    # 优先按“无人机X航迹点数量: N, 航迹点X/Y位置:[...]”进行结构化匹配
    pattern = r'无人机(\d+)航迹点数量\s*[:：]\s*(\d+)\s*,\s*航迹点X/Y位置\s*[:：]\s*\[(.*?)\]'
    matches = re.findall(pattern, clean)

    if len(matches) != 3:
        # 兜底：按方括号顺序提取
        brackets = _extract_bracket_contents(clean)
        if len(brackets) < 3:
            raise ValueError(f"无法从航迹行解析出 3 组坐标: {line[:80]}")
        nodes = []
        segments = []
        for i, b in enumerate(brackets[:3]):
            coords = _extract_all_numbers(b)
            if len(coords) % 2 != 0:
                raise ValueError(f"无人机 {i + 1} 坐标数量为奇数: {len(coords)}")
            nodes.append(coords)
            segments.append(len(coords) // 2)
        return segments, nodes

    # 按无人机编号 1/2/3 排序
    matches = sorted(matches, key=lambda x: int(x[0]))
    segments, nodes = [], []
    for idx, (uav_id_str, count_str, coord_str) in enumerate(matches):
        expected_id = idx + 1
        if int(uav_id_str) != expected_id:
            raise ValueError(f"无人机编号顺序错误，期望 {expected_id}，得到 {uav_id_str}")

        count = int(count_str)
        coords = _extract_all_numbers(coord_str)
        if len(coords) != count * 2:
            raise ValueError(
                f"无人机 {expected_id} 坐标数量与航迹点数量不符: "
                f"count={count}, coords={len(coords)}"
            )
        segments.append(count)
        nodes.append(coords)

    return segments, nodes


def build_full_trajectories(
    target: np.ndarray,
    starts: List[np.ndarray],
    response_nodes: List[List[float]],
    response_segments: Optional[List[int]] = None,
) -> List[np.ndarray]:
    """
    将起点 S 与模型输出的航迹点合并，得到完整航迹。

    Returns:
        List[np.ndarray], 每架无人机航迹 shape (N, 2)，N 为总航迹点数量（含起点）
    """
    if len(starts) != 3 or len(response_nodes) != 3:
        raise ValueError("必须提供 3 架无人机的起点与航迹节点")

    full_trajs = []
    for i in range(3):
        nodes = response_nodes[i]
        if len(nodes) % 2 != 0:
            raise ValueError(f"无人机 {i + 1} 坐标数量为奇数")

        if response_segments is not None:
            if len(nodes) // 2 != response_segments[i]:
                raise ValueError(
                    f"无人机 {i + 1} segment 与坐标数量不一致: "
                    f"segment={response_segments[i]}, coords={len(nodes) // 2}"
                )

        traj = np.concatenate([starts[i].reshape(1, 2),
                               np.array(nodes, dtype=float).reshape(-1, 2)], axis=0)
        full_trajs.append(traj)
    return full_trajs


def turning_angle(p_prev: np.ndarray, p_curr: np.ndarray, p_next: np.ndarray) -> float:
    """
    计算相邻三个航迹点在第 2 个点处的“转弯角”，范围 [0, 90]。

    说明：prompt_contrain 中的“转弯角<=60°”结合 golden 数据校验后，
    采用“方向改变的最小角”定义，即 min(内角, 180 - 内角)。
    - 三点共线时转弯角为 0；
    - 内角为 120°（航向改变 60°）时转弯角为 60°，刚好临界；
    - 内角为 60°（航向改变 120°）时转弯角为 60°，刚好临界；
    - 退化/重合点返回 90（最大惩罚）。
    """
    v1 = np.array(p_prev, dtype=float) - np.array(p_curr, dtype=float)
    v2 = np.array(p_next, dtype=float) - np.array(p_curr, dtype=float)
    norm1, norm2 = np.linalg.norm(v1), np.linalg.norm(v2)
    if norm1 < 1e-8 or norm2 < 1e-8:
        return 90.0
    cos_val = np.dot(v1, v2) / (norm1 * norm2)
    cos_val = np.clip(cos_val, -1.0, 1.0)
    inner = math.degrees(math.acos(cos_val))
    return min(inner, 180.0 - inner)


def path_length(points: np.ndarray) -> float:
    """计算航迹总长度。"""
    pts = np.array(points, dtype=float)
    if len(pts) < 2:
        return 0.0
    return float(np.sum(np.linalg.norm(np.diff(pts, axis=0), axis=1)))


def endpoint_angular_errors(target: np.ndarray, end_points: List[np.ndarray]) -> List[float]:
    """
    计算三架无人机终点相对目标点的方位角与理想 120° 分布的偏差。

    Returns:
        三个偏差值（单位：度），理想情况下均为 0。
    """
    angles = []
    for ep in end_points:
        vec = np.array(ep, dtype=float) - np.array(target, dtype=float)
        ang = math.degrees(math.atan2(vec[1], vec[0]))
        angles.append(ang)

    angles = sorted(angles)
    diffs = [((angles[(i + 1) % 3] - angles[i]) % 360.0) for i in range(3)]
    return [abs(d - 120.0) for d in diffs]


# --------------------------- 奖励超参数 ---------------------------

PENALTY_FORMAT_ERROR = -10.0
PENALTY_POINT_COUNT = -2.0
PENALTY_TURN_ANGLE = 1.5
PENALTY_FINAL_TURN = 2.0
PENALTY_END_DISTANCE = 2.0
PENALTY_END_ANGLE = 2.0
PENALTY_LENGTH_DIFF = 2.0

REWARD_LENGTH_DIFF_OK = 1.0
REWARD_ALL_CONSTRAINTS_OK = 5.0

LENGTH_NORM = 50000.0
LENGTH_WEIGHT = 0.5
EPS = 0.05


# --------------------------- 核心奖励计算 ---------------------------

def _safe_parse(query_text: str, response_text: str):
    """安全解析，解析失败返回 None。"""
    try:
        target, starts = parse_query_line(query_text)
    except Exception:
        return None

    try:
        segments, nodes = parse_trajectory_line(response_text)
    except Exception:
        return None

    try:
        trajs = build_full_trajectories(target, starts, nodes, segments)
    except Exception:
        return None

    return target, starts, segments, trajs


def compute_uav_reward(
    query_text: str,
    response_text: str,
    golden_text: Optional[str] = None,
) -> float:
    """
    计算单条样本的标量奖励。

    Args:
        query_text:    原始问题文本（含 [QUERY] 标签）。
        response_text: 模型生成的回答文本（含 [RESPONSE] 标签）。
        golden_text:   可选，真值文本（含 [LABELS] 标签）。

    Returns:
        float: 奖励值，大致范围 [-10, ~20]。
    """
    parsed = _safe_parse(query_text, response_text)
    if parsed is None:
        return PENALTY_FORMAT_ERROR

    target, starts, segments, trajs = parsed
    reward = 0.0

    # ---- 1. 航迹点数量约束：总点数（含起点）应在 3~10 之间 ----
    point_count_ok = True
    for seg in segments:
        total_points = seg + 1
        if total_points < 3 or total_points > 10:
            reward += PENALTY_POINT_COUNT
            point_count_ok = False

    end_points = [traj[-1] for traj in trajs]
    lengths = [path_length(traj) for traj in trajs]

    # ---- 2. 终点到目标距离 ~= 1000m（连续评分，最重要） ----
    # 每架：误差 0 -> 1.5 分；误差 >= 1000m -> 0 分
    for ep in end_points:
        dist = float(np.linalg.norm(ep - target))
        reward += 1.5 * max(0.0, 1.0 - abs(dist - 1000.0) / 1000.0)

    # ---- 3. 三终点相对目标点互成 120°（连续评分） ----
    angular_errors = endpoint_angular_errors(target, end_points)
    # 每个夹角：误差 0 -> 1.5 分；误差 >= 90° -> 0 分
    reward += 1.5 * sum(max(0.0, 1.0 - e / 90.0) for e in angular_errors)

    # ---- 4. 相邻三点转弯角 <= 60°（连续评分） ----
    # 每架取最大转弯角，最大角 <=60 -> 1.0 分；>=90 -> 0 分
    for traj in trajs:
        max_ang = 0.0
        for j in range(1, len(traj) - 1):
            max_ang = max(max_ang, turning_angle(traj[j - 1], traj[j], traj[j + 1]))
        reward += max(0.0, 1.0 - max(0.0, max_ang - 60.0) / 30.0)

    # ---- 5. 倒数第二点、终点、目标点形成的转弯角 <= 60°（连续评分） ----
    for traj in trajs:
        if len(traj) >= 2:
            angle = turning_angle(traj[-2], traj[-1], target)
            reward += max(0.0, 1.0 - max(0.0, angle - 60.0) / 30.0)

    # ---- 6. 三架总轨迹长度偏差 <= 500m（连续评分） ----
    max_diff = max(lengths) - min(lengths)
    reward += 2.0 * max(0.0, 1.0 - max(0.0, max_diff - 500.0) / 1000.0)

    # ---- 7. 总长度与 golden 对齐（可选） ----
    if golden_text is not None:
        try:
            _, golden_nodes = parse_trajectory_line(golden_text)
            golden_trajs = build_full_trajectories(target, starts, golden_nodes)
            golden_lengths = [path_length(gt) for gt in golden_trajs]
            for pred_len, gold_len in zip(lengths, golden_lengths):
                rel_err = abs(pred_len - gold_len) / (abs(gold_len) + 1e-6)
                reward += max(0.0, 1.0 - rel_err / 0.5)  # 50% 容差
        except Exception:
            pass
    else:
        # 无真值时，对总长度做轻微惩罚，避免无意义绕远
        total_length = sum(lengths)
        reward -= min(total_length / 100000.0, 1.0)

    return float(reward)


# --------------------------- MS-Swift ORM 包装 ---------------------------

class UAVTrajectoryORM(ORM):
    """
    MS-Swift GRPO 外部奖励函数。

    数据集示例（jsonl 中的一行）：
    {
        "messages": [
            {"role": "system", "content": "..."},
            {"role": "user",   "content": "目标点X/Y位置: ..."}
        ],
        "solution": "[LABELS] 无人机1航迹点数量: 5, 航迹点X/Y位置:[...]; ...",
        "query_text": "[QUERY] 目标点X/Y位置: ...; 无人机1航迹起点S: ...; ...",
        "golden_response": "[LABELS] 无人机1航迹点数量: 5, 航迹点X/Y位置:[...]; ..."
    }

    调用示例：
        swift rlhf  --rlhf_type grpo \
                    --external_plugins utils/grpo_reward_func.py \
                    --reward_funcs uav_trajectory \
                    ...
    """

    def __call__(self, completions: List[str], **kwargs) -> List[float]:
        """
        Args:
            completions: List[str]，模型生成的文本列表（GRPO 中 = batch_size * num_generations）。
            kwargs:      MS-Swift 框架自动注入的字典，包含数据集其余列 + trainer_state 等。

        重要约定（来自 MS-Swift 源码）：
        1. completions / solution / query_text / golden_response / messages 等
            都是「与 completions 等长」的列表，需逐元素 zip，而非标量。
        2. 原始 assistant 回答会被框架丢弃，真值必须放到 solution 或自定义列保留。
        3. messages 是 List[List[dict]]，长度与 completions 对齐，用于兜底提取 user 内容。
        """
        n = len(completions)

        def _broadcast(value, n):
            """把标量或列表统一对齐成与 completions 等长的列表。"""
            if value is None:
                return [None] * n
            if isinstance(value, (list, tuple)):
                if len(value) == n:
                    return list(value)
                if len(value) == 1:
                    return [value[0]] * n
                return [None] * n
            return [value] * n

        query_list = _broadcast(kwargs.get('query_text'), n)
        golden_list = _broadcast(kwargs.get('golden_response'), n)
        if all(g is None for g in golden_list):
            golden_list = _broadcast(kwargs.get('solution'), n)

        messages = kwargs.get('messages')
        if not isinstance(messages, (list, tuple)):
            messages = None

        rewards = []
        for i, completion in enumerate(completions):
            query_text = query_list[i]
            golden_text = golden_list[i]

            if not query_text and messages is not None and i < len(messages):
                msg_i = messages[i]
                if isinstance(msg_i, list):
                    for msg in msg_i:
                        if isinstance(msg, dict) and msg.get('role') == 'user':
                            query_text = msg.get('content', '')
                            break
                elif isinstance(msg_i, dict) and msg_i.get('role') == 'user':
                    query_text = msg_i.get('content', '')

            if '[RESPONSE]' not in completion:
                completion = '[RESPONSE] ' + completion

            reward = compute_uav_reward(query_text, completion, golden_text)
            rewards.append(reward)
        return rewards


# 注册到 swift 的 orms 字典
if isinstance(orms, dict):
    orms['uav_trajectory'] = UAVTrajectoryORM


# --------------------------- 本地测试入口 ---------------------------
if __name__ == '__main__':
    q = '[QUERY] 目标点X/Y位置: [798.63, 3867.5]; 无人机1航迹起点S的X/Y位置: [479.97, 445.71]; 无人机2航迹起点S的X/Y位置: [175.6, 148.3]; 无人机3航迹起点S的X/Y位置: [68.54, 341.23]'
    r = '[RESPONSE] 无人机1航迹点数量: 5, 航迹点X/Y位置:[327.5, 596.27, 833.94, 2535.14, 1891.65, 4141.91, 1831.59, 4435.84, 1547.01, 4530.78]; 无人机2航迹点数量: 9, 航迹点X/Y位置:[469.61, 351.22, 410.24, 1087.13, 350.87, 1823.05, 291.5, 2558.97, 232.13, 3294.89, -29.83, 3596.12, -314.41, 3691.06, -374.48, 3984.99, -149.97, 4183.97]; 无人机3航迹点数量: 6, 航迹点X/Y位置:[998.3, 504.02, 1928.06, 666.82, 2069.32, 1053.48, 2210.58, 1440.15, 1604.72, 2163.95, 998.86, 2887.75]'
    print('golden-like reward:', compute_uav_reward(q, r, r))

    r_bad = '[RESPONSE] 无人机1航迹点数量: 2, 航迹点X/Y位置:[0, 0]; 无人机2航迹点数量: 2, 航迹点X/Y位置:[0, 0]; 无人机3航迹点数量: 2, 航迹点X/Y位置:[0, 0]'
    print('bad reward:', compute_uav_reward(q, r_bad))
